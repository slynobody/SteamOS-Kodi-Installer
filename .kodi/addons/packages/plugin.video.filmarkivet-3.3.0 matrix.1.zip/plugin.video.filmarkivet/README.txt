Kodi Filmarkivet addon
----------------------
This addon adds the possiblilty to watch films on Filmarkivet, an archive of
historical Swedish films, provided by the Swedish Film Institute.

Add-on originally created by Anders Piniesjö, now maintained by Ikosse.
