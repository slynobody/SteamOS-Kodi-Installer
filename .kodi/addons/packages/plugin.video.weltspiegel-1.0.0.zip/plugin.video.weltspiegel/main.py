# -*- coding: utf-8 -*-
from libs import libws

ws = libws.libws()
ws.action()
		