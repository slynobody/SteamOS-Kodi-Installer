# -*- coding: utf-8 -*-
import libarte

arte = libarte.libarte()
arte.action()