# plugin.video.zattoo_hiq
Play Live TV and recorded shows from Zattoo.

Support: https://www.kodinerds.net/index.php/Thread/55690-Aus-ZattooBoxExtBeta-wird-ZattooHiQ/

Only for Kodi-19 Matrix
---
